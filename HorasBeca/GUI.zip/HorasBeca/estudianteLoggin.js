var app = angular.module('APPEstudianteLoggin', []);
        app.factory('AngularService', ['$http', function ($http) {
            return {
                //add data service
                Add: function (eCarnet, eEmail) {
                    return $http({
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json; charset=utf-8'
                        },
                        url: 'http://localhost/ApiRegistro/ce/StudentAuth/Token',
                        data: { carne: eCarnet, email:eEmail}
                    });
                }
            };
        }]);
        app.controller('AngularController', function ($scope, $http, AngularService) {
            $scope.formdata = {};
            $scope.add = function () {
                console.log($scope.formdata);
                AngularService.Add("2014046508","a.espiqui@gmail.com");//$scope.formdata.carnet,$scope.formdata.email);
                $scope.formdata = {};
            };
        });