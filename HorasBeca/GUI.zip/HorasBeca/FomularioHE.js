  var app = angular.module('APPHE', []);
        app.factory('AngularService', ['$http', function ($http) {
            return {
                
                Add: function (sSemestre, sCedula, sCarnet, sNombre, sApellido1,sApellido2, sTelefono, sEmail, sPG, sPS, sCuentaBancaria, sTipoBeca, sScreenPG, sScreenPS, sScreenCB, sEstadoE, sEstadoS) {
                    return $http({
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json; charset=utf-8'
                        },
                        url: 'http://192.168.100.24/HorasBecaEstudiante/estudiante/ingresarSolicitud',
                        data: { semestre: sSemestre, cedula:sCedula, carnet: sCarnet, nombre: sNombre, apellido1:sApellido1, apellido2:sApellido2, telefono:sTelefono, email:sEmail, ponderado_general:sPG, ponderado_semestral:sPS, cuenta_bancaria:sCuentaBancaria, tipo_beca:sTipoBeca, screen_ponderado_general:sScreenPG, screen_ponderado_semestral:sScreenPS, screen_cuenta_bancaria:sScreenCB, estado_estudiante:sEstadoE, estado_sistema:sEstadoS}
                       
                    });
                }
            };
        }]);
        
        app.controller('AngularController', function ($scope, $http, AngularService) {
            $scope.formdata = {};
            $scope.add = function () {
                console.log($scope.formdata);
                AngularService.Add("1","12386645","6388789","qgfdsse","adgfcsd","zgfdsc","1584567","qgdsedf@qwffsde","0.21","0.62","cuenta","especial", "NULL","NULL","NULL", "enviada","pendiente");//$scope.formdata.semestre,$scope.formdata.cedula,$scope.formdata.carnet,$scope.formdata.nombre,$scope.formdata.primerApellido,$scope.formdata.segundoApellido,$scope.formdata.telefono,$scope.formdata.email,$scope.formdata.ponderadoGeneral,$scope.formdata.ponderadoAnterior,$scope.formdata.cuentaBancaria, "Tutoria","NULL", "NULL","NULL","enviada","pendiente");
                $scope.formdata = {};
            }; 
            
            $scope.add1 = function () {
                console.log($scope.formdata);
                AngularService.Add("1","12386645","6388789","qgfdsse","adgfcsd","zgfdsc","1584567","qgdsedf@qwffsde","0.21","0.62","cuenta","especial", "NULL","NULL","NULL", "enviada","pendiente");//$scope.formdata.semestre,$scope.formdata.cedula,$scope.formdata.carnet,$scope.formdata.nombre,$scope.formdata.primerApellido,$scope.formdata.segundoApellido,$scope.formdata.telefono,$scope.formdata.email,$scope.formdata.ponderadoGeneral,$scope.formdata.ponderadoAnterior,$scope.formdata.cuentaBancaria, "Tutoria","NULL", "NULL","NULL","enviada","pendiente");
                
            };  
        }
    
        
        
    );


