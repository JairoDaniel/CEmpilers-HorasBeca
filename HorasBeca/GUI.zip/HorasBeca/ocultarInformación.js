function mostrarOcultarDocuBecas() {
    var x = document.getElementById("documentoBecas");
    if (x.style.display === "block") {
        x.style.display = "none" ;
    } else {
        x.style.display = "block";
    }
}

function mostrarOcultarInfoImportante() {
    var x = document.getElementById("infoImportante");
    if (x.style.display === "block") {
        x.style.display = "none" ;
    } else {
        x.style.display = "block";
    }
}

function mostrarOcultarSoliEnviadas() {
    var x = document.getElementById("soliEnviadas");
    if (x.style.display === "block") {
        x.style.display = "none" ;
    } else {
        x.style.display = "block";
    }
}

function mostrarOcultarSoliGuardadas() {
    var x = document.getElementById("soliGuardadas");
    if (x.style.display === "block") {
        x.style.display = "none" ;
    } else {
        x.style.display = "block";
    }
}

function mostrarOcultarSoliCanceladas() {
    var x = document.getElementById("soliCanceladas");
    if (x.style.display === "block") {
        x.style.display = "none" ;
    } else {
        x.style.display = "block";
    }
}