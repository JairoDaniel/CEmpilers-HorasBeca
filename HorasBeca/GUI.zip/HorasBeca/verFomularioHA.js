var app = angular.module('APPMisSolicitudes',[]);
app.controller('AngularController', function ($scope, $http) {
    $scope.getValues = function () {
      $http.get("http://192.168.100.24/HorasBecaEstudiante/estudiante/obtenerSolicitudesEnviadas/3333").then(function (response) {
        $scope.solicitudesEnviadas = response.data;
        //$scope.fecha=$scope.solicitudesEnviadas[0].fecha;
      });
    };
    

  });
