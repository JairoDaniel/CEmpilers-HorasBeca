var app = angular.module('APPEstudianteLogin', []);
app.factory('AngularService', ['$http', function ($http) {

    var getToken = function (eCarne, eEmail) {
            return $http({
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                },
                url: 'http://192.168.100.24/ApiRegistro/ce/StudentAuth/Token',
                data: { carne: eCarne, email:eEmail}
            });
        };
    var getIngresar = function (eCarne, eEmail, eToken) {
            return $http({
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                },
                url: 'http://192.168.100.24/ApiRegistro/ce/StudentAuth/Authenticate',
                data: { carne: eCarne, email:eEmail, token:eToken}
            });
        };

       

    return {
        Token: getToken,
        Ingresar:getIngresar
    };

}]);


app.controller('AngularController', function ($scope, $http, AngularService) {
    $scope.token = function () {
        console.log($scope.formdata);
        AngularService.Token($scope.formdata.carne,$scope.formdata.email);
        $scope.formdata = {};
    };
    $scope.ingresar = function () {
        console.log($scope.formdata);
        var toe = AngularService.Ingresar("2014046508", "a.espqui@gmail.com", 
        "x6yxHJYjVD7dT4WEgS3VVbe6rr2SC6YDUp76pDIwUgAnKTxEvLGOQHZVovZl0MgWRyLvv8SJM5C3zZ+DL0F0wfMo/xR+pyc0DBd+Q3x4UAxQPJeIt1N6xmMoHlC+sSgh");//$scope.formdata.carne, $scope.formdata.email, $scope.formdata.token);
      
        toe.then(data => {if(data.status=="200")
							 {  
								$scope.acuerdo('bien', data.data.carne)
							 }
						  else{
							   $scope.acuerdo('mal');
							 };});
        //var xf= toe.then(data => {console.log(data.status);});
        $scope.formdata = {};

    };
    
    $scope.acuerdo = function (trigger, ident) {
           if (trigger=="bien"){
			  document.cookie = "username=John Doe"; 
			  
				location.href='acuerdo.html';
		   }
		   else if (trigger=="mal"){
				location.href='estudiante.html';
		   }
		  
    };
    
    
    

    $scope.formdata = {};
});




