var app = angular.module('APPAcuerdo',[]);
app.controller('AngularController', function ($scope, $http) {
    $scope.getValues = function () {    
		 var x = document.cookie; 
				console.log(x);
    };
  });
