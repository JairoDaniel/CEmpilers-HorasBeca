

function iniciar(){ 

  var boton=document.getElementById('boton'); 

  boton.addEventListener('click', leer, false); 


 

  
  
} 
function leer(){ 
  var url="comision/texto.txt"; 	
  var solicitud=new XMLHttpRequest(); 
  solicitud.addEventListener('load',mostrar,false); 
  solicitud.open("GET", url, true); 
  solicitud.send(null); 
  
  
} 

function mostrar(e){ 
  var table = document.getElementById("myTable");
  var len = document.getElementById("myTable").rows.length;
  var filas=5;
  var data=e.target.responseText;
  var firstLine = data.split('\n'); 
  for (var x=1; x<firstLine.length;x++){
	  var row = table.insertRow(x);
	  var local= firstLine[x-1].split('\ ');
	  for (var y=0; y<=4; y++){
			var cell = row.insertCell(y);
			cell.innerHTML = local[y];
	   }
      var cell = row.insertCell(5);
      cell.innerHTML = '<input type="BUTTON" id="BUTTON" value="Ver" />';
    
     
  }
} 


window.addEventListener('load', iniciar, false);


    




