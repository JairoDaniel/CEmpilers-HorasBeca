var app = angular.module("APPMisSolicitudes", []);
app.controller("AngularController", function($scope) {
  $scope.solicitudes = [
    {
    "Id" : "Alfreds Futterkiste",
    "Tipo" : "Solicitud de beca HE",
    "Estado" : "Enviado"
    },
    {
    "Id" : "Alfreds Futterkiste",
    "Tipo" : "Solicitud de beca HE",
    "Estado" : "Enviado"
    },
    {
    "Id" : "Alfreds Futterkiste",
    "Tipo" : "Solicitud de beca HE",
    "Estado" : "Enviado"
    }
  ]
});
